package salonv;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Saiara pc
 */
public class Division {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double x=15;
        double y=0; //se divide entre cero
      //se desarrola la excepcion
      try{
        System.out.println("El resultado de la division de "+x+"entre"+y+"es: "+division(x,y));
        //se crea mi_excepcion para guardar el error
    }catch(Exception mi_excepcion){
        System.out.println("Ha intentado dividir entre cero");
        System.out.println("El objeto excepcion lanzado es :"+mi_excepcion.toString());
    }
    }
    public static double division(double dividendo, double divisor){
        return(dividendo/divisor);
    }
}
