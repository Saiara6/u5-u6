package salonv;


import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Saiara pc
 */
public class Excepcion {

       
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
       Scanner nums = new Scanner (System.in);
      int x=0,y=0,z=0,k=0;
      boolean repetir;
      do{
          repetir=false;
          try{
              System.out.println("Introduzca el primer valor:");
                      x=nums.nextInt();
                      
              System.out.println("Introduzca el segundo valor:");
                      y=nums.nextInt();
                      
              System.out.println("Introduzca el tercer valor:");
                      z=nums.nextInt();
                      
              System.out.println("Introduzca el cuarto valor:");
                      k=nums.nextInt();
                      // se asigna e para atrapar el error
          }catch(java.util.InputMismatchException e ){ 
              //se concatena el metodo toString a la variabla asignada en catch para obtener el valor de esta 
              System.err.println("Valor NO Valido"+e.toString());
              nums.nextLine();
              repetir=true;
          }
          }while(repetir);
          System.out.println("valor introducido: " +x);
          System.out.println("valor introducido: " +y);
          System.out.println("valor introducido: " +z);
          System.out.println("valor introducido: " +k);
      }
    }
