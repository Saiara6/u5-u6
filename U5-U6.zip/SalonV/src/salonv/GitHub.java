/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package salonv;

import java.util.Scanner;

/**
 *
 * @author downb
 */
public class GitHub {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner nums = new Scanner (System.in);
        int x=0,y=0,z=0,k=0;
        boolean repetir;
        do{
            repetir=false;
            try{
              
            System.out.println("Introduzca el primer valor");
                x=nums.nextInt();
            System.out.println("Introduzca el segundo valor");
                y=nums.nextInt();
            System.out.println("Introduzca el tercer valor");
                z=nums.nextInt();
            System.out.println("Introduzca el cuarto valor");
                k=nums.nextInt();
                }
            //Se crea la variable "e" al momento de escribir lo de catch con el error generado
        catch(java.util.InputMismatchException e){
            //Se concadena el metodo toString a la variable asignada en catch "e"  para obtener el valor de esta y saber porque mostramos el mensaje
                System.err.println("Valor no valido"+e.toString());
                nums.nextLine();
                repetir=true;
                }
    }
        while (repetir);
        System.out.println("valor introducido; "+x);
        System.out.println("valor introducido; "+y);
        System.out.println("valor introducido; "+z);
        System.out.println("valor introducido; "+k);
        }
}
