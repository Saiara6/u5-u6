/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package salonv;

import java.io.*;
import java.util.*;

/**
 *
 * @author downb
 */
public class Ficheros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // Hacer uso del bloque try y catch (se escribira todo el problema que haremos)
        try {
            File file = new File("Entrada_salida3.txt");
            //Se lanza NullPointerException, si la cadena esta vacia
            //Crear el archivo si NO existe
            boolean success = file.createNewFile();
            //Lanzamos IOException o SecurityException
            if (success) {
                //Ela rchivo NO existe, se crea
                System.out.println("El archivo NO existe y se crea");
                //Comprar si el achivo permite lectura/escritura
                System.out.println("El archivo permite escribir " + file.canWrite());
                System.out.println("El archivo permite leer " + file.canRead());

                BufferedWriter file_escribir = new BufferedWriter(new FileWriter(file));
                //Lanza IOException
                file_escribir.newLine();
                file_escribir.write("12");
                //Lanza IOException
                file_escribir.newLine();
                file_escribir.write("24");
                //Lanza IOException
                file_escribir.newLine();
                //flush se utiliza para vaciar
                file_escribir.flush();
                file_escribir.close();
                //Ahora se abre el fichero para la lectura
                //para esto se utiliza la clase scanner
                Scanner file_lectura = new Scanner(file);
                //Se lanza FileNotFoundException
                //leer cadenas de caracteres del mismo
                String leer = file_lectura.nextLine();
                //Lanza IllegalStateException
                //NoSuchElementException
                String leer2 = file_lectura.nextLine();
                String leer3 = file_lectura.nextLine();

                double leer_double;
                int leer_int;
                leer_double = Double.parseDouble(leer2);
                //Lanzar NumberFormatException
                leer_int = Integer.parseInt(leer3);
                //Mostrar consola con las diversas cadenas
                System.out.println("la cadena leida es: " + leer);
                System.out.println("la cadena leida es: " + leer_double);
                System.out.println("la cadena leida es: " + leer_int);
            } else {
                System.out.println("El archivo ya existe y por lo tanto NO SE CREO");
            }

        } catch (FileNotFoundException f_exception) {
            //el archivo      
            System.out.println("Las operaciones de lectura NO se han podido realizar");
            System.err.println("Ha ocurrido un problema al buscar el archivo para lectura");
            System.err.println(f_exception.toString());

        } catch (IOException io_exception) {
            System.err.println("Ha ocurrido un ERROR en la E/S de datos");
            System.out.println(io_exception.toString());

        } catch (NumberFormatException nb_exception) {
            //La exception ocurre al intentar realizar una conversion de una cadena de caracteres a una tipo numerica
            System.err.println("Ha ocurrido un ERROR de conversion de caracteres.");
            System.out.println(nb_exception.toString());

        } catch (NoSuchElementException nse_exception) {
            //Ocurre cuando el metodo NextLine() no halla la cadena
            System.err.println("No se ha hallado el elemento en el Scanner");
            System.out.println(nse_exception.toString());
        } catch (Exception e_exception){
            System.out.println(e_exception.toString());
        }
        
    }
}
