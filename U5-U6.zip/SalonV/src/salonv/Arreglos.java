package salonv;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Saiara pc
 */
public class Arreglos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try{
            mostrarArray();
        }catch(ArrayIndexOutOfBoundsException e) {
            System.out.println("Ha intenado acceder a un posicion fuera del arreglo");
        }
    }
    //aw crea metodo
    public static void mostrarArray(){
        int[]array ={1,2,3};
        //se valida tamaño del arreglo
        for(int j=0;j<=3;j++);
        int j = 0;
            System.out.println(array[j]);
    }
}
